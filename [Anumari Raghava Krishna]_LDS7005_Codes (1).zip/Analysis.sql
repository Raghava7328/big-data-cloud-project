SELECT *
FROM processed_us_accidents_parquet
LIMIT 10;

-- Query 2: Accidents by State
-- Purpose:
-- Identify the US states with the highest
-- number of recorded traffic accidents.
--
-- Business Insight:
-- Supports smart city traffic planning,
-- resource allocation, and infrastructure
-- safety improvements.
SELECT state,
       COUNT(*) AS total_accidents
FROM processed_us_accidents_parquet
GROUP BY state
ORDER BY total_accidents DESC
LIMIT 10;

-- Query 3: Severity by Weather Condition
-- Purpose: Analyse how weather conditions influence
-- accident severity across the dataset.
-- Business Insight:
-- Helps transportation agencies identify
-- dangerous weather patterns and improve
-- weather-aware traffic management systems.
SELECT weather_condition,
       ROUND(AVG(severity), 2) AS avg_severity,
       COUNT(*) AS accident_count
FROM processed_us_accidents_parquet
GROUP BY weather_condition
HAVING COUNT(*) > 10000
ORDER BY avg_severity DESC
LIMIT 10;

-- ============================================
-- Query 4: Peak Accident Hours
-- Purpose:
-- Identify the hours of the day with the
-- highest number of traffic accidents.
-- Business Insight:
-- Supports emergency response planning,
-- traffic management optimisation, and
-- road safety strategy development.
-- ============================================

SELECT hour,
       COUNT(*) AS accident_count
FROM processed_us_accidents_parquet
GROUP BY hour
ORDER BY accident_count DESC;


-- Query 5: Traffic Signal Impact
-- Purpose:
-- Evaluate accident frequency and severity
-- near traffic signal locations.
--
-- Business Insight:
-- Assists smart city planners in assessing
-- the effectiveness of traffic signal
-- infrastructure for road safety.

SELECT traffic_signal,
       COUNT(*) AS accident_count,
       ROUND(AVG(severity), 2) AS avg_severity
FROM processed_us_accidents_parquet
GROUP BY traffic_signal;


-- Query 6: Top Dangerous Cities
-- Purpose: Identify cities with high accident counts
-- and high average accident severity.

SELECT city,
       state,
       COUNT(*) AS total_accidents,
       ROUND(AVG(severity),2) AS avg_severity
FROM processed_us_accidents_parquet
WHERE city IS NOT NULL
GROUP BY city, state
HAVING COUNT(*) > 1000
ORDER BY avg_severity DESC
LIMIT 10;

-- Query 7: Weekend vs Weekday Accidents
-- Purpose:
-- Compare accident frequency and severity
-- between weekdays and weekends.
SELECT CASE
		WHEN day_of_week IN (1, 7) THEN 'Weekend' ELSE 'Weekday'
	END AS day_type,
	COUNT(*) AS total_accidents,
	ROUND(AVG(severity), 2) AS avg_severity
FROM processed_us_accidents_parquet
GROUP BY CASE
		WHEN day_of_week IN (1, 7) THEN 'Weekend' ELSE 'Weekday'
	END;