import sys

from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col,
    year,
    month,
    to_timestamp,
    hour,
    dayofweek
)

# This ETL pipeline is designed to process the
# US Accidents dataset using Apache Spark.
# The workflow demonstrates large-scale data
# engineering practices including distributed
# data ingestion, transformation, cleaning,
# and storage in an optimized analytical format.


# Create Spark Session

# A Spark session serves as the entry point
# for interacting with Apache Spark.
spark = SparkSession.builder \
    .appName("AnumariUSAccidentsETL") \
    .getOrCreate()


# Define Amazon S3 Paths

# Source location containing raw accident data
input_path = "s3://us-accidents-smartcity-anumari/raw/us_accidents/"

# Destination location for transformed parquet files
output_path = "s3://us-accidents-smartcity-anumari/processed/us_accidents_parquet/"


# Read CSV Dataset

# The dataset is loaded with automatic schema inference
# and header recognition for structured processing.
df = spark.read \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .csv(input_path)


# Data Cleaning and Transformation

# This transformation stage removes duplicate records,
# converts timestamp fields into Spark timestamp format,
# and extracts temporal features that are useful for
# downstream analytical and machine learning tasks.
df_clean = (
    df.dropDuplicates(["ID"])

      .withColumn(
          "Start_Time",
          to_timestamp(col("Start_Time"))
      )

      .withColumn(
          "End_Time",
          to_timestamp(col("End_Time"))
      )

      .withColumn(
          "year",
          year(col("Start_Time"))
      )

      .withColumn(
          "month",
          month(col("Start_Time"))
      )

      .withColumn(
          "hour",
          hour(col("Start_Time"))
      )

      .withColumn(
          "day_of_week",
          dayofweek(col("Start_Time"))
      )

      .filter(col("Severity").isNotNull())

      .filter(col("Start_Lat").isNotNull())

      .filter(col("Start_Lng").isNotNull())
)


# Handle Missing Values

# Missing numerical and categorical values are replaced
# with default placeholders to improve data consistency
# and reduce issues during analytical processing.
df_clean = df_clean.fillna({

    "Weather_Condition": "Unknown",

    "Temperature(F)": 0,

    "Humidity(%)": 0,

    "Visibility(mi)": 0,

    "Wind_Speed(mph)": 0,

    "Precipitation(in)": 0
})


# Write Processed Data as Partitioned Parquet Files

# The parquet format provides efficient columnar storage,
# while partitioning by year and state improves query
# performance in distributed analytics environments.
df_clean.write \
    .mode("overwrite") \
    .partitionBy("year", "State") \
    .parquet(output_path)


# Stop Spark Session

# Releasing Spark resources after pipeline execution.
spark.stop()