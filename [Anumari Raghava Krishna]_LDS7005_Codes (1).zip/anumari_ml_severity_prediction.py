import pandas as pd
import joblib
import boto3
import matplotlib.pyplot as plt
import pyarrow.dataset as ds

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay
)

# Defining the Amazon S3 bucket that stores the processed accident dataset.
bucket_name = "us-accidents-smartcity-anumari"

# Constructing the S3 path containing the processed Parquet files.
s3_path = f"s3://{bucket_name}/processed/us_accidents_parquet/"

# The selected features represent weather conditions, traffic infrastructure,
# spatial characteristics, and temporal information associated with accidents.
features = [
    "Temperature(F)",
    "Humidity(%)",
    "Visibility(mi)",
    "Wind_Speed(mph)",
    "Precipitation(in)",
    "Weather_Condition",
    "Traffic_Signal",
    "Junction",
    "Crossing",
    "hour",
    "City"
]

# Accident severity is used as the target variable for classification.
target = "Severity"

# Combining predictor variables and target column
# for selective dataset loading.
columns_to_load = features + [target]

print("Loading maximum 1000 rows from processed Parquet dataset in S3...")

# The dataset is accessed directly from Amazon S3 using PyArrow,
# which enables efficient columnar reading from Parquet storage.
dataset = ds.dataset(s3_path, format="parquet")

# Only the first 1000 rows are imported in order to reduce
# memory consumption and avoid EC2 instance termination issues.
table = dataset.scanner(columns=columns_to_load).head(1000)

# Converting the Arrow table into a Pandas DataFrame
# for preprocessing and machine learning operations.
df = table.to_pandas()

# Displaying the imported dataset dimensions verifies
# successful ingestion and confirms row limitations.
print("Imported shape:", df.shape)

# Creating a separate machine learning dataframe ensures
# isolation from the original imported dataset.
ml_df = df.copy()

# Rows without target labels are removed to preserve
# supervised learning consistency.
ml_df = ml_df.dropna(subset=[target])

# Missing categorical values are replaced with "Unknown"
# to avoid null handling issues during encoding.
ml_df["Weather_Condition"] = ml_df["Weather_Condition"].fillna("Unknown")
ml_df["City"] = ml_df["City"].fillna("Unknown")

# Numerical variables selected for preprocessing.
numeric_cols = [
    "Temperature(F)",
    "Humidity(%)",
    "Visibility(mi)",
    "Wind_Speed(mph)",
    "Precipitation(in)",
    "hour"
]

# Missing numerical values are imputed with zeros
# to maintain dataset consistency.
for col in numeric_cols:
    ml_df[col] = ml_df[col].fillna(0)

# Ensuring that accident severity is interpreted
# as an integer classification label.
ml_df[target] = ml_df[target].astype(int)

# Categorical variables requiring one-hot encoding
# before model training.
categorical_cols = [
    "Weather_Condition",
    "Traffic_Signal",
    "Junction",
    "Crossing",
    "City"
]

# Separating predictor features and target labels.
X = ml_df[features]
y = ml_df[target]

# The preprocessing pipeline applies one-hot encoding
# to categorical variables while preserving numeric values.
preprocessor = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_cols)
    ],
    remainder="passthrough"
)

# A Random Forest classifier is selected because of its
# robustness, ensemble learning capability,
# and effectiveness in classification tasks.
model = Pipeline(
    steps=[
        ("preprocessor", preprocessor),
        ("classifier", RandomForestClassifier(
            n_estimators=50,
            max_depth=8,
            random_state=42,
            n_jobs=1
        ))
    ]
)

# The dataset is divided into training and testing subsets
# using stratified sampling to preserve class distribution.
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

print("Training Random Forest model...")

# Training the machine learning pipeline using
# the prepared training dataset.
model.fit(X_train, y_train)

print("Evaluating model...")

# Predicting accident severity for unseen test observations.
y_pred = model.predict(X_test)

# Computing overall model classification accuracy.
accuracy = accuracy_score(y_test, y_pred)

print("\nModel Accuracy:", round(accuracy, 4))

# Displaying precision, recall, and F1-score metrics
# for each accident severity class.
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Constructing the confusion matrix to evaluate
# prediction performance across severity categories.
cm = confusion_matrix(y_test, y_pred)

# Visualizing the confusion matrix for interpretation.
disp = ConfusionMatrixDisplay(confusion_matrix=cm)
disp.plot()

plt.title("Accident Severity Prediction - Confusion Matrix")

# Saving the confusion matrix as a high-resolution image
# for reporting and documentation purposes.
plt.savefig(
    "anumari_confusion_matrix.png",
    dpi=300,
    bbox_inches="tight"
)

# Persisting the trained Random Forest model locally
# for future deployment and reuse.
model_file = "anumari_accident_severity_random_forest.pkl"
joblib.dump(model, model_file)

print("Model saved locally:", model_file)
print("Confusion matrix saved locally: anumari_confusion_matrix.png")

# Initializing the Amazon S3 client for cloud uploads.
s3 = boto3.client("s3")

# Uploading the trained machine learning model
# to the designated S3 output directory.
s3.upload_file(
    model_file,
    bucket_name,
    "ml/model-output/anumari_accident_severity_random_forest.pkl"
)

# Uploading the confusion matrix image to S3
# for remote access and result visualization.
s3.upload_file(
    "anumari_confusion_matrix.png",
    bucket_name,
    "ml/model-output/anumari_confusion_matrix.png"
)

print("Model and confusion matrix uploaded to S3 successfully.")