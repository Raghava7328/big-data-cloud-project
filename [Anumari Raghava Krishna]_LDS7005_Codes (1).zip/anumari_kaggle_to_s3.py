import kagglehub
import os
import boto3

# This script automates the process of downloading the
# US Accidents dataset from Kaggle and storing it in
# an Amazon S3 bucket for scalable cloud-based access.
# Such a workflow is commonly used in big data analytics,
# distributed computing, and data engineering pipelines.


# Configuration Parameters

# Kaggle dataset identifier
DATASET = "sobhanmoosavi/us-accidents"

# Target Amazon S3 bucket name
BUCKET_NAME = "us-accidents-smartcity-anumari"

# Folder structure inside the S3 bucket
S3_PREFIX = "raw/us_accidents/"


# Step 1: Download the dataset from Kaggle

print("Starting Kaggle dataset download...")

# The dataset is downloaded locally using kagglehub
path = kagglehub.dataset_download(DATASET)

print(f"Dataset downloaded successfully to: {path}")


# Step 2: Establish connection with Amazon S3

# Create an S3 client using boto3
# AWS credentials should already be configured
# in the local environment or AWS CLI
s3 = boto3.client("s3")


# Step 3: Upload dataset files to Amazon S3

print("Starting upload to Amazon S3...")

# Traverse all files and subdirectories
# within the downloaded dataset folder
for root, dirs, files in os.walk(path):

    for file in files:

        # Full local file path
        local_file_path = os.path.join(root, file)

        # Relative file path to preserve folder structure
        relative_path = os.path.relpath(local_file_path, path)

        # Destination object key in S3
        s3_key = S3_PREFIX + relative_path

        print(f"Uploading {file} to s3://{BUCKET_NAME}/{s3_key}")

        # Upload file to the specified S3 bucket
        s3.upload_file(local_file_path, BUCKET_NAME, s3_key)


# Completion Message

print("Dataset uploaded successfully to S3")